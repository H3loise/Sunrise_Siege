package Model.Obstacles;

/**
 * Enum classe pour la taille des obstacles, c'est plus facile à manipuler et controlâble.
 */

public enum Taille {
    Small,Average,Big;
}

